"""
Speech-to-Text engines for MARK XL.

Whisper – offline transcription via faster-whisper (VAD-buffered)
Vosk    – offline streaming transcription (lighter)
"""

import json
import numpy as np


class WhisperSTT:
    """Offline transcription using faster-whisper."""

    def __init__(self, model_name: str = "base", language: str | None = None):
        import os
        from faster_whisper import WhisperModel

        print(f"[STT] Loading Whisper '{model_name}'…")

        try:
            import torch
            device = "cuda" if torch.cuda.is_available() else "cpu"
            compute = "float16" if device == "cuda" else "int8"
        except Exception:
            device, compute = "cpu", "int8"

        try:
            self._model = WhisperModel(
                model_name,
                device=device,
                compute_type=compute,
            )
        except Exception as first_err:
            # If the model is not cached, clear offline flags and try once
            # with internet access so the model can be downloaded.
            error_text = str(first_err).lower()
            offline_keywords = (
                "offline",
                "not found",
                "cache",
                "localentry",
                "does not exist",
                "outgoing",
                "local_files_only",
            )

            if any(keyword in error_text for keyword in offline_keywords):
                print(
                    f"[STT] Whisper '{model_name}' not in local cache — "
                    "downloading (one-time, internet required)…"
                )

                os.environ.pop("HF_HUB_OFFLINE", None)
                os.environ.pop("TRANSFORMERS_OFFLINE", None)
                os.environ.pop("HF_DATASETS_OFFLINE", None)

                try:
                    self._model = WhisperModel(
                        model_name,
                        device=device,
                        compute_type=compute,
                    )
                except Exception as download_err:
                    raise RuntimeError(
                        f"Whisper '{model_name}' model download failed.\n"
                        "Internet access is required the first time to download "
                        "the speech model (~75–290 MB).\n"
                        "After the first download it runs fully offline.\n"
                        f"Details: {download_err}"
                    ) from download_err
            else:
                raise

        self._language = (
            None
            if not language or language.strip().lower() == "auto"
            else language.strip().lower()
        )

        print(f"[STT] Whisper '{model_name}' ready ({device})")

    def transcribe(self, audio: np.ndarray) -> str:
        """
        Transcribe a float32 mono 16 kHz numpy array.

        Returns:
            str: Transcript text.
        """
        try:
            segments, _ = self._model.transcribe(
                audio,
                language=self._language,
                beam_size=1,
                best_of=1,
                condition_on_previous_text=False,
                vad_filter=True,
                vad_parameters={"min_silence_duration_ms": 300},
            )

            return " ".join(segment.text for segment in segments).strip()

        except Exception as error:
            print(f"[STT] Transcription error: {error}")
            raise


class VoskSTT:
    """Streaming transcription using Vosk."""

    def __init__(
        self,
        model_path: str | None = None,
        language: str = "en-us",
    ):
        from vosk import Model, KaldiRecognizer

        print("[STT] Loading Vosk model…")

        if model_path:
            model = Model(model_path)
        else:
            lang = (
                language.strip().lower()
                if language and language.strip().lower() != "auto"
                else "en-us"
            )
            model = Model(lang=lang)

        self._rec = KaldiRecognizer(model, 16000)

        print("[STT] Vosk ready.")

    def process_chunk(self, audio_bytes: bytes) -> tuple[str, bool]:
        """
        Feed raw int16 little-endian PCM bytes.

        Returns:
            tuple[str, bool]: (text, is_final)
        """
        if self._rec.AcceptWaveform(audio_bytes):
            result = json.loads(self._rec.Result())
            return result.get("text", ""), True

        partial = json.loads(self._rec.PartialResult())
        return partial.get("partial", ""), False
